import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseStorage

struct EditProfileView: View {
    @Binding var username: String
    @Binding var profileImageURL: String
    @Binding var refreshTrigger: Bool // ✅ Ensures ProfileView refreshes

    @State private var newUsername: String = ""
    @State private var selectedImage: UIImage?
    @State private var imagePickerPresented = false
    @Environment(\.presentationMode) var presentationMode // ✅ Allows back navigation

    var body: some View {
        VStack(spacing: 20) {
            // ✅ HEADER WITH PROFILE IMAGE
            ZStack {
                Color(hex: "#2A4D69") // Dark blue header
                    .frame(height: 180)
                    .edgesIgnoringSafeArea(.top)

                VStack {
                    // ✅ Show Selected Image if Available
                    if let selectedImage = selectedImage {
                        Image(uiImage: selectedImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 110, height: 110)
                            .clipShape(Circle())
                    } else if let url = URL(string: profileImageURL), !profileImageURL.isEmpty {
                        AsyncImage(url: url) { image in
                            image.resizable()
                                .scaledToFill()
                        } placeholder: {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .foregroundColor(.gray)
                        }
                        .frame(width: 110, height: 110)
                        .clipShape(Circle())
                    } else {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .foregroundColor(.gray)
                            .frame(width: 110, height: 110)
                            .clipShape(Circle())
                    }

                    Button(action: { imagePickerPresented = true }) {
                        Text("Change Picture")
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .padding(8)
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                    }
                }
            }
            .padding(.bottom, 20)

            // ✅ USERNAME FIELD
            VStack(alignment: .leading, spacing: 15) {
                Text("New Username")
                    .font(.headline)
                    .foregroundColor(.black)

                TextField("Enter new username", text: $newUsername)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)

            Spacer()

            // ✅ SAVE CHANGES BUTTON
            Button(action: saveProfileChanges) {
                Text("Save Changes")
                    .bold()
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(hex: "#2A4D69"))
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .background(Color(hex: "#D6E6F2").edgesIgnoringSafeArea(.all))
        .sheet(isPresented: $imagePickerPresented) {
            ImagePicker(selectedImage: $selectedImage)
        }
    }

    // ✅ FUNCTION TO SAVE PROFILE CHANGES
    func saveProfileChanges() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()
        let storageRef = Storage.storage().reference().child("profile_pictures/\(userID).jpg")

        var updatedData: [String: Any] = [:]

        // ✅ Update username if changed
        if !newUsername.isEmpty {
            updatedData["username"] = newUsername
            username = newUsername // Update local UI immediately
        }

        // ✅ Upload Image if a new one is selected
        if let selectedImage = selectedImage, let imageData = selectedImage.jpegData(compressionQuality: 0.5) {
            storageRef.putData(imageData, metadata: nil) { _, error in
                if let error = error {
                    print("❌ Error uploading image: \(error)")
                    return
                }
                storageRef.downloadURL { url, error in
                    if let url = url {
                        updatedData["profileImageURL"] = url.absoluteString
                        profileImageURL = url.absoluteString // Update UI immediately
                        saveToFirestore(data: updatedData)
                    } else {
                        print("❌ Failed to retrieve image URL: \(error?.localizedDescription ?? "Unknown error")")
                    }
                }
            }
        } else {
            // ✅ If no image change, just update Firestore
            saveToFirestore(data: updatedData)
        }
    }

    // ✅ FUNCTION TO UPDATE FIRESTORE
    private func saveToFirestore(data: [String: Any]) {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()
        db.collection("users").document(userID).updateData(data) { error in
            if let error = error {
                print("❌ Error updating profile: \(error)")
            } else {
                print("✅ Profile updated successfully!")
                refreshTrigger.toggle() // ✅ Forces ProfileView to update
                presentationMode.wrappedValue.dismiss() // ✅ Navigate back to ProfileView
            }
        }
    }
}
