import SwiftUI

struct EventCard: View {
    let event: Event

    var body: some View {
        NavigationLink(destination: EventDetailView(event: event)) { // ✅ Updated to EventDetailView
            VStack(alignment: .leading) {
                AsyncImage(url: URL(string: event.imageUrl)) { image in
                    image.resizable()
                        .scaledToFit()
                        .cornerRadius(10)
                } placeholder: {
                    Image(systemName: "photo") // Placeholder if no image
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(10)
                        .foregroundColor(.gray)
                        .frame(height: 150)
                }

                Text(event.title)
                    .font(.headline)
                    .foregroundColor(.primary)

                Text(event.date)
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                Text(event.location)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(20) // Ticket-like rounded corners
            .shadow(radius: 3)
        }
        .buttonStyle(PlainButtonStyle()) // ✅ Remove default NavigationLink styling
    }
}
