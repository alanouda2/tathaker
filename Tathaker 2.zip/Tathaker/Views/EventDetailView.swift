import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct EventDetailView: View {
    let event: Event
    let estimatedTime = "\(Int.random(in: 10...45)) minutes away" // Fake estimated time
    @Environment(\.presentationMode) var presentationMode // For navigation back
    
    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 15) { // ✅ Centered content
                
                // ✅ Event Image (From Assets)
                Image("BaladnaFarm") // ✅ Using asset image
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 250)
                    .cornerRadius(10)
                    .padding()
                
                // ✅ Estimated Time (Centered)
                Text(estimatedTime)
                    .font(.headline)
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity) // ✅ Centers the text
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 5)
                
                // ✅ Event Description (Full Scrollable View)
                Text(event.description)
                    .font(.body)
                    .padding(.horizontal, 20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true) // Ensure full display
                
                Spacer()
                
                // ✅ Google Maps Preview (Placeholder)
                VStack {
                    Rectangle()
                        .fill(Color.gray.opacity(0.3))
                        .frame(height: 200)
                        .overlay(
                            Image(systemName: "map")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80, height: 80)
                                .foregroundColor(.gray)
                        )
                    
                    // ✅ Get Directions Button (Disabled for now)
                    Button(action: {}) {
                        Text("Get Directions")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    .disabled(true) // Non-functional for now
                }
                .padding()
                
                // ✅ Book Now Button (Saves ticket to Firestore)
                Button(action: {
                    navigateToPayment = true
                }) {
                    Text("Book Ticket")
                        .font(.title2)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(hex: "#2a4d69"))
                        .cornerRadius(10)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                .sheet(isPresented: $navigateToPayment) {
                    FakePaymentView(event: event) // Pass event details to the payment screen
                }
            }
            .background(Color(hex: "#D6E6F2").edgesIgnoringSafeArea(.all))
            .navigationBarTitle(event.title, displayMode: .inline) // ✅ Title in navigation bar
        }
        
        // ✅ Fake Payment Processing (Saves Ticket to Firestore)
        func processFakePayment() {
            guard let userID = Auth.auth().currentUser?.uid else {
                print("User not logged in.")
                return
            }
            
            let db = Firestore.firestore()
            let ticketID = "\(userID)_\(event.id)"
            
            let ticketData: [String: Any] = [
                "userID": userID,
                "eventID": event.id,
                "eventTitle": event.title,
                "eventDate": event.date,
                "eventLocation": event.location,
                "paymentMethod": "Fake Credit Card", // ✅ Fake payment
                "ticketQR": "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=\(event.id)_\(userID)"
            ]
            
            db.collection("tickets").document(ticketID).setData(ticketData) { error in
                if let error = error {
                    print("Error booking ticket: \(error)")
                } else {
                    print("Ticket booked successfully!")
                    presentationMode.wrappedValue.dismiss() // ✅ Navigate back to events list
                }
            }
        }
    }
}
